import React from 'react'

const About = () => {
  return (
    <div>
        This is About Page
    </div>
  )
}

export default About